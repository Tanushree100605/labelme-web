// Single place to point the frontend at your backend.
// Change this if your API runs on a different host/port, or wire it up to
// an environment-specific build step later.
export const API_BASE_URL = 'http://localhost:8000/api';
