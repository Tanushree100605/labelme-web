import { state, on, emit } from './state.js';
import * as api from './apiClient.js';
import { openFolderOnBackend, saveClasses, saveAnnotationsForImage } from './persistence.js';
import { initClassManager, renderClassList } from './classManager.js';
import { renderImageList, scrollActiveImageIntoView } from './imageList.js';
import { renderAnnotationList } from './annotationList.js';
import {
  initCanvasEditor, showImage, deleteSelectedAnnotation, selectAnnotation, updateClassHint, redraw,
} from './canvasEditor.js';

// ---- DOM refs -------------------------------------------------------------
const emptyState = document.getElementById('empty-state');
const appShell = document.getElementById('app-shell');
const btnOpenFolder = document.getElementById('btn-open-folder');
const btnOpenFolder2 = document.getElementById('btn-open-folder-2');
const backendWarning = document.getElementById('backend-warning');
const folderNameEl = document.getElementById('folder-name');
const formatBadge = document.getElementById('format-badge');
const saveStatusEl = document.getElementById('save-status');
const btnSave = document.getElementById('btn-save');
const btnPrev = document.getElementById('btn-prev');
const btnNext = document.getElementById('btn-next');
const connIndicator = document.getElementById('conn-indicator');
const connLabel = connIndicator.querySelector('.conn-label');

const formatModal = document.getElementById('format-modal');
const folderPathInput = document.getElementById('folder-path-input');
const formatModalError = document.getElementById('format-modal-error');
const formatModalCancel = document.getElementById('format-modal-cancel');
const formatModalSubmit = document.getElementById('format-modal-submit');

const toastEl = document.getElementById('toast');

const FORMAT_LABELS = { coco: 'COCO JSON', voc: 'Pascal VOC XML', yolo: 'YOLO TXT' };

let selectedFormat = null;
let saveTimer = null;

// ---- boot -------------------------------------------------------------
function boot() {
  initClassManager();
  initCanvasEditor();
  wireTopLevelEvents();
  wireStateEvents();
  pollBackendHealth();
}

async function pollBackendHealth() {
  const ok = await api.checkHealth();
  setConnState(ok);
  setTimeout(pollBackendHealth, 8000);
}

function setConnState(ok) {
  state.backendConnected = ok;
  connIndicator.classList.toggle('online', ok);
  connIndicator.classList.toggle('offline', !ok);
  connLabel.textContent = ok ? 'backend connected' : 'backend unreachable';
  backendWarning.classList.toggle('hidden', ok);
}

function wireTopLevelEvents() {
  btnOpenFolder.addEventListener('click', openModal);
  btnOpenFolder2.addEventListener('click', openModal);
  btnSave.addEventListener('click', () => persistNow(true));

  btnPrev.addEventListener('click', () => navigate(-1));
  btnNext.addEventListener('click', () => navigate(1));

  folderPathInput.addEventListener('input', updateSubmitEnabled);

  formatModal.querySelectorAll('.format-card').forEach(card => {
    card.addEventListener('click', () => {
      selectedFormat = card.dataset.format;
      formatModal.querySelectorAll('.format-card').forEach(c => c.classList.toggle('selected', c === card));
      updateSubmitEnabled();
    });
  });

  formatModalCancel.addEventListener('click', closeModal);
  formatModalSubmit.addEventListener('click', submitOpenFolder);

  document.addEventListener('keydown', (e) => {
    if (!formatModal.classList.contains('hidden') && e.key === 'Enter' && !formatModalSubmit.disabled) {
      submitOpenFolder();
      return;
    }
    const inInput = ['INPUT', 'TEXTAREA'].includes(document.activeElement?.tagName);
    if (inInput) return;

    if (e.key === 'Delete' || e.key === 'Backspace') {
      if (deleteSelectedAnnotation()) { scheduleAutoSave(); e.preventDefault(); }
    } else if (e.key === 'ArrowLeft') {
      navigate(-1);
    } else if (e.key === 'ArrowRight') {
      navigate(1);
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      persistNow(true);
    }
  });
}

function wireStateEvents() {
  on('select-image', async (idx) => {
    if (idx === state.currentImageIndex) return;
    await persistNow(false);
    await goToImage(idx);
  });

  on('select-annotation', (id) => selectAnnotation(id));

  on('selection-changed', () => renderAnnotationList());

  on('annotations-changed', () => {
    renderAnnotationList();
    renderImageList();
    scheduleAutoSave();
  });

  on('classes-changed', async () => {
    renderClassList();
    updateClassHint();
    redraw();
    try {
      await saveClasses();
    } catch (err) {
      showToast(`Could not save classes to backend: ${err.message}`, true);
    }
  });

  on('active-class-changed', () => updateClassHint());
}

// ---- folder open modal -------------------------------------------------------------

function openModal() {
  selectedFormat = null;
  folderPathInput.value = state.folderPath || '';
  formatModalError.classList.add('hidden');
  formatModal.querySelectorAll('.format-card').forEach(c => c.classList.remove('selected'));
  updateSubmitEnabled();
  formatModal.classList.remove('hidden');
  folderPathInput.focus();
}

function closeModal() {
  formatModal.classList.add('hidden');
}

function updateSubmitEnabled() {
  formatModalSubmit.disabled = !(folderPathInput.value.trim() && selectedFormat);
}

async function submitOpenFolder() {
  const path = folderPathInput.value.trim();
  if (!path || !selectedFormat) return;

  formatModalSubmit.disabled = true;
  formatModalSubmit.textContent = 'Opening…';
  formatModalError.classList.add('hidden');

  try {
    await openFolderOnBackend(path, selectedFormat);

    if (state.images.length === 0) {
      formatModalError.textContent = 'That folder has no supported images (jpg, png, bmp, webp, gif).';
      formatModalError.classList.remove('hidden');
      return;
    }

    closeModal();
    emptyState.classList.add('hidden');
    appShell.classList.remove('hidden');
    folderNameEl.textContent = state.folderName;
    formatBadge.textContent = FORMAT_LABELS[state.format];
    formatBadge.classList.remove('badge-hidden');
    btnSave.disabled = false;

    renderClassList();
    renderImageList();
    state.currentImageIndex = -1;
    await goToImage(0);

    showToast(`Loaded ${state.images.length} image${state.images.length === 1 ? '' : 's'} as ${FORMAT_LABELS[state.format]}.`);
  } catch (err) {
    formatModalError.textContent = err.message || 'Could not open that folder.';
    formatModalError.classList.remove('hidden');
  } finally {
    formatModalSubmit.disabled = false;
    formatModalSubmit.textContent = 'Open folder';
    updateSubmitEnabled();
  }
}

// ---- navigation -----------------------------------------------------------

async function goToImage(idx) {
  if (idx < 0 || idx >= state.images.length) return;
  state.currentImageIndex = idx;
  state.selectedAnnotationId = null;
  renderImageList();
  scrollActiveImageIntoView();
  renderAnnotationList();
  try {
    await showImage(state.images[idx]);
  } catch (err) {
    showToast(`Could not load image: ${err.message}`, true);
  }
}

async function navigate(delta) {
  if (state.images.length === 0) return;
  const next = state.currentImageIndex + delta;
  if (next < 0 || next >= state.images.length) return;
  await persistNow(false);
  await goToImage(next);
}

// ---- saving -----------------------------------------------------------

function scheduleAutoSave() {
  state.dirty = true;
  setSaveStatus('saving');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => persistNow(false), 600);
}

async function persistNow(manual) {
  clearTimeout(saveTimer);
  if (!state.sessionId) return;
  if (!state.dirty && !manual) return;

  const img = state.images[state.currentImageIndex];
  if (!img) return;

  setSaveStatus('saving');
  try {
    await saveAnnotationsForImage(img.name);
    state.dirty = false;
    setSaveStatus('saved');
  } catch (err) {
    console.error(err);
    setSaveStatus('error');
    showToast(`Save failed: ${err.message}`, true);
  }
}

function setSaveStatus(kind) {
  saveStatusEl.classList.remove('saving', 'saved', 'error');
  if (kind === 'saving') {
    saveStatusEl.textContent = 'Saving…';
    saveStatusEl.classList.add('saving');
  } else if (kind === 'saved') {
    saveStatusEl.textContent = 'Saved';
    saveStatusEl.classList.add('saved');
    setTimeout(() => { if (saveStatusEl.textContent === 'Saved') saveStatusEl.textContent = ''; }, 2000);
  } else if (kind === 'error') {
    saveStatusEl.textContent = 'Save failed';
    saveStatusEl.classList.add('error');
  } else {
    saveStatusEl.textContent = '';
  }
}

// ---- toast -----------------------------------------------------------

let toastTimer = null;
function showToast(msg, isError = false) {
  toastEl.textContent = msg;
  toastEl.classList.toggle('error', isError);
  toastEl.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastEl.classList.add('hidden'), 3200);
}

boot();
