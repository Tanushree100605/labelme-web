// All network calls to the backend live here. Nothing else in the frontend
// should call `fetch` directly — this keeps the API contract in one place.
// See docs/API_CONTRACT.md for the full request/response spec this client
// implements.

import { API_BASE_URL } from './config.js';

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function request(path, options = {}) {
  let res;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch (err) {
    throw new ApiError(`Could not reach the backend at ${API_BASE_URL}. Is it running?`, 0);
  }

  if (!res.ok) {
    let detail = '';
    try { detail = (await res.json()).message || ''; } catch { /* ignore */ }
    throw new ApiError(detail || `Request failed (${res.status})`, res.status);
  }
  if (res.status === 204) return null;
  return res.json();
}

/** GET /health — used to show a connected/disconnected indicator. */
export async function checkHealth() {
  try {
    await request('/health');
    return true;
  } catch {
    return false;
  }
}

/**
 * POST /folders/open — opens (or re-opens) a folder on the backend's
 * filesystem, with the chosen annotation format, and returns everything
 * needed to hydrate the frontend in one shot: image list (with natural
 * sizes), classes, and any annotations already on disk in that format.
 */
export async function openFolder(path, format) {
  return request('/folders/open', {
    method: 'POST',
    body: JSON.stringify({ path, format }),
  });
}

/** Builds a direct, cacheable URL the <img>/canvas can load the image bytes from. */
export function imageFileUrl(sessionId, imageName) {
  return `${API_BASE_URL}/folders/${encodeURIComponent(sessionId)}/images/${encodeURIComponent(imageName)}/file`;
}

/** PUT /folders/:sessionId/classes — persists the current class list. */
export async function saveClasses(sessionId, classes) {
  return request(`/folders/${encodeURIComponent(sessionId)}/classes`, {
    method: 'PUT',
    body: JSON.stringify({ classes: classes.map(c => ({ id: c.id, name: c.name })) }),
  });
}

/**
 * PUT /folders/:sessionId/annotations/:imageName — persists the boxes for a
 * single image. The backend is responsible for writing this out in whatever
 * format (COCO/VOC/YOLO) the folder session was opened with.
 */
export async function saveAnnotationsForImage(sessionId, imageName, boxes) {
  return request(`/folders/${encodeURIComponent(sessionId)}/annotations/${encodeURIComponent(imageName)}`, {
    method: 'PUT',
    body: JSON.stringify({
      boxes: boxes.map(b => ({ id: b.id, classId: b.classId, x: b.x, y: b.y, w: b.w, h: b.h })),
    }),
  });
}

export { ApiError };
