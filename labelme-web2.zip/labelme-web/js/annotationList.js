import { state, classById, currentAnnotations, emit } from './state.js';

const listEl = document.getElementById('annotation-list');
const countEl = document.getElementById('annotation-count');

export function renderAnnotationList() {
  const boxes = currentAnnotations();
  countEl.textContent = String(boxes.length);
  listEl.innerHTML = '';

  if (boxes.length === 0) {
    const hint = document.createElement('div');
    hint.className = 'annotation-empty-hint';
    hint.textContent = state.images.length
      ? 'No boxes on this image yet. Pick a class, then drag on the image.'
      : 'Open a folder to get started.';
    listEl.appendChild(hint);
    return;
  }

  boxes.forEach(box => {
    const cls = classById(box.classId);
    const row = document.createElement('div');
    row.className = 'annotation-row' + (box.id === state.selectedAnnotationId ? ' selected' : '');

    const swatch = document.createElement('span');
    swatch.className = 'swatch';
    swatch.style.background = cls ? cls.color : '#888';

    const info = document.createElement('div');
    info.className = 'info';
    const cname = document.createElement('span');
    cname.className = 'cname';
    cname.textContent = cls ? cls.name : 'Unknown class';
    const coords = document.createElement('span');
    coords.className = 'coords';
    coords.textContent = `${Math.round(box.x)}, ${Math.round(box.y)}  ${Math.round(box.w)}×${Math.round(box.h)}`;
    info.appendChild(cname);
    info.appendChild(coords);

    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '✕';
    del.title = 'Delete this annotation';
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      const arr = currentAnnotations();
      const idx = arr.findIndex(b => b.id === box.id);
      if (idx !== -1) arr.splice(idx, 1);
      if (state.selectedAnnotationId === box.id) state.selectedAnnotationId = null;
      emit('annotations-changed');
      emit('selection-changed');
    });

    row.appendChild(swatch);
    row.appendChild(info);
    row.appendChild(del);

    row.addEventListener('click', () => emit('select-annotation', box.id));

    listEl.appendChild(row);
  });
}
