// Central, plain-object app state + a tiny pub/sub so modules can react
// to changes without a framework.

export const CLASS_COLORS = [
  '#5b8cff', '#3ecf8e', '#f2a93b', '#ef5a6f', '#c084fc',
  '#38bdf8', '#facc15', '#fb923c', '#4ade80', '#f472b6',
  '#a3e635', '#22d3ee', '#e879f9', '#fbbf24', '#60a5fa',
];

export const state = {
  sessionId: null,        // opaque handle the backend gave us for this folder
  folderPath: '',
  folderName: '',
  format: null,           // 'coco' | 'voc' | 'yolo'
  backendConnected: false,

  classes: [],             // [{ id, name, color }]
  activeClassId: null,

  images: [],               // [{ name, width, height }]
  currentImageIndex: -1,

  // annotations[imageName] = [{ id, classId, x, y, w, h }]  (x,y,w,h in ORIGINAL image pixels)
  annotations: {},

  // per-image natural size cache: imageSizes[imageName] = { width, height }
  imageSizes: {},

  selectedAnnotationId: null,
  dirty: false,             // unsaved changes since last write
};

let nextClassId = 1;
let nextAnnotationId = 1;

export function newClassId() { return nextClassId++; }
export function newAnnotationId() { return nextAnnotationId++; }
export function bumpClassId(n) { if (n >= nextClassId) nextClassId = n + 1; }
export function bumpAnnotationId(n) { if (n >= nextAnnotationId) nextAnnotationId = n + 1; }

const listeners = {};
export function on(event, cb) {
  (listeners[event] = listeners[event] || []).push(cb);
}
export function emit(event, payload) {
  (listeners[event] || []).forEach(cb => cb(payload));
}

export function currentImage() {
  return state.images[state.currentImageIndex] || null;
}

export function currentAnnotations() {
  const img = currentImage();
  if (!img) return [];
  return state.annotations[img.name] || (state.annotations[img.name] = []);
}

export function classById(id) {
  return state.classes.find(c => c.id === id) || null;
}

export function nextClassColor() {
  return CLASS_COLORS[state.classes.length % CLASS_COLORS.length];
}
