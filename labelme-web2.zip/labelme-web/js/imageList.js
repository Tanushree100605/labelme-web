import { state, emit } from './state.js';

const listEl = document.getElementById('image-list');
const countEl = document.getElementById('image-count');

export function renderImageList() {
  listEl.innerHTML = '';
  countEl.textContent = String(state.images.length);

  state.images.forEach((img, idx) => {
    const hasAnnotations = (state.annotations[img.name] || []).length > 0;

    const row = document.createElement('div');
    row.className = 'image-item' +
      (idx === state.currentImageIndex ? ' active' : '') +
      (hasAnnotations ? ' has-annotations' : '');

    const dot = document.createElement('span');
    dot.className = 'dot';
    dot.title = hasAnnotations ? 'Has annotations' : 'No annotations yet';

    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = img.name;

    const n = document.createElement('span');
    n.className = 'n';
    n.textContent = String(idx + 1);

    row.appendChild(dot);
    row.appendChild(name);
    row.appendChild(n);

    row.addEventListener('click', () => {
      emit('select-image', idx);
    });

    listEl.appendChild(row);
  });
}

export function scrollActiveImageIntoView() {
  const active = listEl.querySelector('.image-item.active');
  if (active) active.scrollIntoView({ block: 'nearest' });
}
