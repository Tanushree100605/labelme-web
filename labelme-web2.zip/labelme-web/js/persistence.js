// Thin bridge between app state and the backend. All format-specific
// encoding (COCO/VOC/YOLO) and filesystem writes happen server-side — this
// module just shuttles the generic { classes, images, annotations } shape
// back and forth. See docs/API_CONTRACT.md.

import { state } from './state.js';
import * as api from './apiClient.js';
import { CLASS_COLORS } from './state.js';

/**
 * Open a folder on the backend and hydrate app state from its response.
 * Throws on failure (network error, folder not found, etc.) — caller shows
 * the error to the user.
 */
export async function openFolderOnBackend(path, format) {
  const res = await api.openFolder(path, format);

  state.sessionId = res.sessionId;
  state.folderPath = path;
  state.folderName = res.folderName || path;
  state.format = res.format || format;

  state.classes = (res.classes || []).map((c, i) => ({
    id: c.id,
    name: c.name,
    color: CLASS_COLORS[i % CLASS_COLORS.length],
  }));
  state.activeClassId = state.classes[0]?.id ?? null;

  state.images = (res.images || []).map(im => ({ name: im.name }));
  state.imageSizes = {};
  (res.images || []).forEach(im => {
    state.imageSizes[im.name] = { width: im.width || 0, height: im.height || 0 };
  });

  state.annotations = {};
  Object.entries(res.annotations || {}).forEach(([imageName, boxes]) => {
    state.annotations[imageName] = boxes.map(b => ({
      id: b.id ?? cryptoId(),
      classId: b.classId,
      x: b.x, y: b.y, w: b.w, h: b.h,
    }));
  });
}

/** Push the current class list to the backend. */
export async function saveClasses() {
  if (!state.sessionId) return;
  await api.saveClasses(state.sessionId, state.classes);
}

/** Push the current image's annotations to the backend. */
export async function saveAnnotationsForImage(imageName) {
  if (!state.sessionId) return;
  const boxes = state.annotations[imageName] || [];
  await api.saveAnnotationsForImage(state.sessionId, imageName, boxes);
}

function cryptoId() {
  return `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}
