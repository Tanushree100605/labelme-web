import { state, classById, currentAnnotations, newAnnotationId, emit } from './state.js';
import { imageFileUrl } from './apiClient.js';

const canvas = document.getElementById('editor-canvas');
const ctx = canvas.getContext('2d');
const canvasInner = document.getElementById('canvas-inner');
const canvasWrap = document.getElementById('canvas-wrap');
const emptyHint = document.getElementById('canvas-empty-hint');
const currentImageNameEl = document.getElementById('current-image-name');
const zoomLevelEl = document.getElementById('zoom-level');
const activeClassHintEl = document.getElementById('active-class-hint');

const HANDLE_SIZE = 9;       // px, screen space
const HIT_PADDING = 4;       // px, screen space, for edge/body hit testing
const MIN_BOX_SIZE = 4;      // px, image space

let loadedImg = null;        // current <img> element
let fitScale = 1;            // scale that fits the image to the viewport
let zoom = 1;                // user-controlled multiplier on top of fitScale
let scale = 1;                // effective scale = fitScale * zoom

let drag = null;              // active pointer interaction, see startDrag()

export function initCanvasEditor() {
  document.getElementById('btn-zoom-in').addEventListener('click', () => setZoom(zoom * 1.25));
  document.getElementById('btn-zoom-out').addEventListener('click', () => setZoom(zoom / 1.25));
  document.getElementById('btn-zoom-reset').addEventListener('click', () => setZoom(1));

  canvas.addEventListener('pointerdown', onPointerDown);
  window.addEventListener('pointermove', onPointerMove);
  window.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('mousemove', updateCursor);

  window.addEventListener('resize', () => {
    if (loadedImg) { computeFitScale(); redraw(); };
  });
}

export async function showImage(imageMeta) {
  state.selectedAnnotationId = null;

  const url = imageFileUrl(state.sessionId, imageMeta.name);
  const img = new Image();
  await new Promise((resolve, reject) => {
    img.onload = resolve;
    img.onerror = () => reject(new Error(`Could not load image from backend: ${imageMeta.name}`));
    img.src = url;
  });
  loadedImg = img;
  state.imageSizes[imageMeta.name] = {
    width: imageMeta.width || img.naturalWidth,
    height: imageMeta.height || img.naturalHeight,
  };

  currentImageNameEl.textContent = imageMeta.name;
  emptyHint.classList.add('hidden');
  canvasInner.classList.add('visible');

  zoom = 1;
  computeFitScale();
  redraw();
  updateClassHint();
}

export function clearCanvas() {
  loadedImg = null;
  currentImageNameEl.textContent = '—';
  emptyHint.classList.remove('hidden');
  canvasInner.classList.remove('visible');
}

function computeFitScale() {
  if (!loadedImg) return;
  const maxW = Math.max(200, canvasWrap.clientWidth - 48);
  const maxH = Math.max(200, canvasWrap.clientHeight - 48);
  fitScale = Math.min(maxW / loadedImg.naturalWidth, maxH / loadedImg.naturalHeight, 2.5);
  if (!Number.isFinite(fitScale) || fitScale <= 0) fitScale = 1;
  applyScale();
}

function setZoom(z) {
  zoom = Math.max(0.2, Math.min(z, 6));
  applyScale();
  redraw();
}

function applyScale() {
  scale = fitScale * zoom;
  if (!loadedImg) return;
  canvas.width = Math.round(loadedImg.naturalWidth * scale);
  canvas.height = Math.round(loadedImg.naturalHeight * scale);
  zoomLevelEl.textContent = `${Math.round(zoom * 100)}%`;
}

export function redraw() {
  if (!loadedImg) return;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(loadedImg, 0, 0, canvas.width, canvas.height);

  const boxes = currentAnnotations();
  boxes.forEach(box => drawBox(box, box.id === state.selectedAnnotationId));

  if (drag && drag.type === 'create') {
    const r = normalizeRect(drag.startImg, drag.currentImg);
    drawRectStroke(toScreenRect(r), activeColor(), true);
  }
}

function activeColor() {
  const cls = classById(state.activeClassId);
  return cls ? cls.color : '#5b8cff';
}

function drawBox(box, selected) {
  const cls = classById(box.classId);
  const color = cls ? cls.color : '#888';
  const rect = toScreenRect(box);
  drawRectStroke(rect, color, selected);

  // label chip
  const label = cls ? cls.name : '?';
  ctx.font = '600 11px Inter, sans-serif';
  const padX = 6;
  const textW = ctx.measureText(label).width;
  const chipH = 18;
  const chipW = textW + padX * 2;
  const chipY = rect.y - chipH >= 0 ? rect.y - chipH : rect.y;

  ctx.fillStyle = color;
  ctx.globalAlpha = 0.92;
  ctx.fillRect(rect.x, chipY, chipW, chipH);
  ctx.globalAlpha = 1;
  ctx.fillStyle = '#0b1220';
  ctx.fillText(label, rect.x + padX, chipY + 13);

  if (selected) {
    handlesFor(rect).forEach(h => {
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.rect(h.x - HANDLE_SIZE / 2, h.y - HANDLE_SIZE / 2, HANDLE_SIZE, HANDLE_SIZE);
      ctx.fill();
      ctx.stroke();
    });
  }
}

function drawRectStroke(rect, color, emphasized) {
  ctx.lineWidth = emphasized ? 2.5 : 2;
  ctx.strokeStyle = color;
  ctx.fillStyle = hexToRgba(color, 0.12);
  ctx.beginPath();
  ctx.rect(rect.x, rect.y, rect.w, rect.h);
  ctx.fill();
  ctx.stroke();
}

function hexToRgba(hex, alpha) {
  const n = parseInt(hex.slice(1), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r},${g},${b},${alpha})`;
}

// ---- coordinate helpers -----------------------------------------------

function toScreenRect(box) {
  return { x: box.x * scale, y: box.y * scale, w: box.w * scale, h: box.h * scale };
}

function toImagePoint(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (clientX - rect.left) / scale,
    y: (clientY - rect.top) / scale,
  };
}

function normalizeRect(a, b) {
  const x = Math.min(a.x, b.x);
  const y = Math.min(a.y, b.y);
  const w = Math.abs(a.x - b.x);
  const h = Math.abs(a.y - b.y);
  return { x, y, w, h };
}

function handlesFor(rect) {
  return [
    { pos: 'nw', x: rect.x, y: rect.y },
    { pos: 'ne', x: rect.x + rect.w, y: rect.y },
    { pos: 'sw', x: rect.x, y: rect.y + rect.h },
    { pos: 'se', x: rect.x + rect.w, y: rect.y + rect.h },
  ];
}

// ---- hit testing --------------------------------------------------------

function findHandleAt(clientX, clientY) {
  const selected = currentAnnotations().find(b => b.id === state.selectedAnnotationId);
  if (!selected) return null;
  const rect = canvas.getBoundingClientRect();
  const sx = clientX - rect.left, sy = clientY - rect.top;
  for (const h of handlesFor(toScreenRect(selected))) {
    if (Math.abs(sx - h.x) <= HANDLE_SIZE && Math.abs(sy - h.y) <= HANDLE_SIZE) return h.pos;
  }
  return null;
}

function findBoxAt(clientX, clientY) {
  const rect = canvas.getBoundingClientRect();
  const sx = clientX - rect.left, sy = clientY - rect.top;
  const boxes = currentAnnotations();
  for (let i = boxes.length - 1; i >= 0; i--) {
    const r = toScreenRect(boxes[i]);
    if (sx >= r.x - HIT_PADDING && sx <= r.x + r.w + HIT_PADDING &&
        sy >= r.y - HIT_PADDING && sy <= r.y + r.h + HIT_PADDING) {
      return boxes[i];
    }
  }
  return null;
}

// ---- pointer interaction --------------------------------------------------

function onPointerDown(e) {
  if (!loadedImg) return;
  canvas.setPointerCapture(e.pointerId);
  const imgPt = toImagePoint(e.clientX, e.clientY);

  // 1) resizing a handle on the currently selected box
  const handlePos = findHandleAt(e.clientX, e.clientY);
  if (handlePos) {
    const box = currentAnnotations().find(b => b.id === state.selectedAnnotationId);
    drag = { type: 'resize', handle: handlePos, box, origBox: { ...box } };
    return;
  }

  // 2) clicking an existing box -> select + prepare to move
  const hit = findBoxAt(e.clientX, e.clientY);
  if (hit) {
    state.selectedAnnotationId = hit.id;
    drag = {
      type: 'move', box: hit,
      offset: { x: imgPt.x - hit.x, y: imgPt.y - hit.y },
    };
    emit('selection-changed');
    redraw();
    return;
  }

  // 3) empty space: start drawing a new box, if a class is active
  state.selectedAnnotationId = null;
  emit('selection-changed');
  if (state.activeClassId == null) {
    redraw();
    return;
  }
  drag = { type: 'create', startImg: imgPt, currentImg: imgPt };
  redraw();
}

function onPointerMove(e) {
  if (!drag || !loadedImg) return;
  const imgPt = clampToImage(toImagePoint(e.clientX, e.clientY));

  if (drag.type === 'create') {
    drag.currentImg = imgPt;
    redraw();
  } else if (drag.type === 'move') {
    const box = drag.box;
    box.x = clamp(imgPt.x - drag.offset.x, 0, loadedImg.naturalWidth - box.w);
    box.y = clamp(imgPt.y - drag.offset.y, 0, loadedImg.naturalHeight - box.h);
    redraw();
  } else if (drag.type === 'resize') {
    applyResize(drag, imgPt);
    redraw();
  }
}

function onPointerUp() {
  if (!drag) return;

  if (drag.type === 'create') {
    const r = normalizeRect(drag.startImg, drag.currentImg);
    if (r.w >= MIN_BOX_SIZE && r.h >= MIN_BOX_SIZE) {
      const box = { id: newAnnotationId(), classId: state.activeClassId, x: r.x, y: r.y, w: r.w, h: r.h };
      currentAnnotations().push(box);
      state.selectedAnnotationId = box.id;
      emit('annotations-changed');
      emit('selection-changed');
    }
  } else if (drag.type === 'move' || drag.type === 'resize') {
    emit('annotations-changed');
  }

  drag = null;
  redraw();
}

function applyResize(d, imgPt) {
  const orig = d.origBox;
  let x1 = orig.x, y1 = orig.y, x2 = orig.x + orig.w, y2 = orig.y + orig.h;

  if (d.handle.includes('w')) x1 = imgPt.x;
  if (d.handle.includes('e')) x2 = imgPt.x;
  if (d.handle.includes('n')) y1 = imgPt.y;
  if (d.handle.includes('s')) y2 = imgPt.y;

  const box = d.box;
  box.x = Math.min(x1, x2);
  box.y = Math.min(y1, y2);
  box.w = Math.max(MIN_BOX_SIZE, Math.abs(x2 - x1));
  box.h = Math.max(MIN_BOX_SIZE, Math.abs(y2 - y1));
}

function updateCursor(e) {
  if (drag) return;
  const handlePos = findHandleAt(e.clientX, e.clientY);
  if (handlePos) {
    canvas.style.cursor = (handlePos === 'nw' || handlePos === 'se') ? 'nwse-resize' : 'nesw-resize';
    return;
  }
  const hit = findBoxAt(e.clientX, e.clientY);
  canvas.style.cursor = hit ? 'move' : 'crosshair';
}

function clampToImage(pt) {
  if (!loadedImg) return pt;
  return clampPoint(pt, loadedImg.naturalWidth, loadedImg.naturalHeight);
}
function clampPoint(pt, w, h) {
  return { x: clamp(pt.x, 0, w), y: clamp(pt.y, 0, h) };
}
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

export function deleteSelectedAnnotation() {
  if (state.selectedAnnotationId == null) return false;
  const boxes = currentAnnotations();
  const idx = boxes.findIndex(b => b.id === state.selectedAnnotationId);
  if (idx === -1) return false;
  boxes.splice(idx, 1);
  state.selectedAnnotationId = null;
  emit('annotations-changed');
  emit('selection-changed');
  redraw();
  return true;
}

export function selectAnnotation(id) {
  state.selectedAnnotationId = id;
  emit('selection-changed');
  redraw();
}

function updateClassHint() {
  if (state.classes.length === 0) {
    activeClassHintEl.textContent = 'Add a class on the right before you can draw boxes.';
  } else if (state.activeClassId == null) {
    activeClassHintEl.textContent = 'Select a class on the right, then click and drag on the image to draw a box.';
  } else {
    const cls = classById(state.activeClassId);
    activeClassHintEl.textContent = `Drawing with class "${cls?.name}". Click and drag on the image.`;
  }
}
export { updateClassHint };
