import { state, newClassId, nextClassColor, emit } from './state.js';

const listEl = document.getElementById('class-list');
const formEl = document.getElementById('class-form');
const inputEl = document.getElementById('class-input');

export function initClassManager() {
  formEl.addEventListener('submit', (e) => {
    e.preventDefault();
    const name = inputEl.value.trim();
    if (!name) return;
    if (state.classes.some(c => c.name.toLowerCase() === name.toLowerCase())) {
      inputEl.value = '';
      return;
    }
    const cls = { id: newClassId(), name, color: nextClassColor() };
    state.classes.push(cls);
    state.activeClassId = cls.id;
    inputEl.value = '';
    emit('classes-changed');
  });

  renderClassList();
}

export function renderClassList() {
  listEl.innerHTML = '';

  if (state.classes.length === 0) {
    const hint = document.createElement('div');
    hint.className = 'class-empty-hint';
    hint.textContent = 'Add a class above to start annotating. Each class gets its own color.';
    listEl.appendChild(hint);
    return;
  }

  state.classes.forEach(cls => {
    const row = document.createElement('div');
    row.className = 'class-row' + (cls.id === state.activeClassId ? ' active' : '');
    row.dataset.classId = cls.id;

    const swatch = document.createElement('span');
    swatch.className = 'swatch';
    swatch.style.background = cls.color;

    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = cls.name;

    const del = document.createElement('button');
    del.className = 'del';
    del.title = `Delete class "${cls.name}"`;
    del.textContent = '✕';
    del.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteClass(cls.id);
    });

    row.appendChild(swatch);
    row.appendChild(name);
    row.appendChild(del);

    row.addEventListener('click', () => {
      state.activeClassId = cls.id;
      renderClassList();
      emit('active-class-changed');
    });

    listEl.appendChild(row);
  });
}

function deleteClass(classId) {
  const cls = state.classes.find(c => c.id === classId);
  if (!cls) return;
  const usageCount = Object.values(state.annotations)
    .reduce((sum, boxes) => sum + boxes.filter(b => b.classId === classId).length, 0);

  if (usageCount > 0) {
    const ok = confirm(
      `"${cls.name}" is used on ${usageCount} annotation${usageCount === 1 ? '' : 's'} across this folder. ` +
      `Deleting it will remove those annotations too. Continue?`
    );
    if (!ok) return;
    Object.keys(state.annotations).forEach(imageName => {
      state.annotations[imageName] = state.annotations[imageName].filter(b => b.classId !== classId);
    });
  }

  state.classes = state.classes.filter(c => c.id !== classId);
  if (state.activeClassId === classId) {
    state.activeClassId = state.classes[0]?.id ?? null;
  }
  renderClassList();
  emit('classes-changed');
  emit('annotations-changed');
}
