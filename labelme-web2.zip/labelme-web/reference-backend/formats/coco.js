// COCO JSON: a single annotations.json describing every image in the folder.

export const COCO_FILENAME = 'annotations.json';

export function buildCoco(session) {
  const categories = session.classes.map(c => ({ id: c.id, name: c.name, supercategory: 'none' }));
  const images = [];
  const annotations = [];
  let annId = 1;

  session.images.forEach((img, idx) => {
    images.push({ id: idx + 1, file_name: img.name, width: img.width, height: img.height });
    const boxes = session.annotations[img.name] || [];
    boxes.forEach(box => {
      annotations.push({
        id: annId++,
        image_id: idx + 1,
        category_id: box.classId,
        bbox: [round2(box.x), round2(box.y), round2(box.w), round2(box.h)],
        area: round2(box.w * box.h),
        iscrowd: 0,
      });
    });
  });

  return {
    info: { description: 'Created with Annotator (reference backend)', version: '1.0' },
    licenses: [],
    images,
    annotations,
    categories,
  };
}

export function parseCoco(json) {
  const classes = (json.categories || []).map(cat => ({ id: cat.id, name: cat.name }));
  const imageIdToName = {};
  (json.images || []).forEach(im => { imageIdToName[im.id] = im.file_name; });

  const annotationsByImage = {};
  (json.annotations || []).forEach(ann => {
    const name = imageIdToName[ann.image_id];
    if (!name) return;
    const [x, y, w, h] = ann.bbox || [0, 0, 0, 0];
    (annotationsByImage[name] = annotationsByImage[name] || []).push({ classId: ann.category_id, x, y, w, h });
  });

  return { classes, annotationsByImage };
}

function round2(n) { return Math.round(n * 100) / 100; }
