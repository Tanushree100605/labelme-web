export const YOLO_CLASSES_FILENAME = 'classes.txt';

export function yoloFilenameFor(baseName) {
  return `${baseName}.txt`;
}

export function buildYoloTxt(boxes, imgWidth, imgHeight, classIndexOf) {
  if (!imgWidth || !imgHeight) return '';
  return boxes.map(b => {
    const cx = (b.x + b.w / 2) / imgWidth;
    const cy = (b.y + b.h / 2) / imgHeight;
    const w = b.w / imgWidth;
    const h = b.h / imgHeight;
    return `${classIndexOf(b.classId)} ${fmt(cx)} ${fmt(cy)} ${fmt(w)} ${fmt(h)}`;
  }).join('\n') + (boxes.length ? '\n' : '');
}

export function buildClassesTxt(classes) {
  return classes.map(c => c.name).join('\n') + (classes.length ? '\n' : '');
}

export function parseClassesTxt(text) {
  return text.split('\n').map(l => l.trim()).filter(Boolean);
}

export function parseYoloTxt(text, imgWidth, imgHeight) {
  return text.split('\n').map(l => l.trim()).filter(Boolean).map(line => {
    const [classIndex, cx, cy, w, h] = line.split(/\s+/).map(Number);
    return {
      classIndex,
      x: (cx - w / 2) * imgWidth,
      y: (cy - h / 2) * imgHeight,
      w: w * imgWidth,
      h: h * imgHeight,
    };
  }).filter(b => Number.isFinite(b.classIndex) && Number.isFinite(b.x));
}

function fmt(n) { return Math.max(0, Math.min(1, n)).toFixed(6); }
