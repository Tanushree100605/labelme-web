// Pascal VOC XML: one <image-basename>.xml file per image.
// Hand-rolled build + parse (regex-based) to avoid an extra XML dependency —
// fine for this controlled, simple schema.

export function vocFilenameFor(baseName) {
  return `${baseName}.xml`;
}

function escapeXml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

export function buildVocXml({ imageName, folderName, width, height, boxes, classNameOf }) {
  const objects = boxes.map(b => {
    const xmin = Math.round(b.x), ymin = Math.round(b.y);
    const xmax = Math.round(b.x + b.w), ymax = Math.round(b.y + b.h);
    return `  <object>
    <name>${escapeXml(classNameOf(b.classId) || 'unknown')}</name>
    <pose>Unspecified</pose>
    <truncated>0</truncated>
    <difficult>0</difficult>
    <bndbox>
      <xmin>${xmin}</xmin>
      <ymin>${ymin}</ymin>
      <xmax>${xmax}</xmax>
      <ymax>${ymax}</ymax>
    </bndbox>
  </object>`;
  }).join('\n');

  return `<annotation>
  <folder>${escapeXml(folderName || '')}</folder>
  <filename>${escapeXml(imageName)}</filename>
  <size>
    <width>${width}</width>
    <height>${height}</height>
    <depth>3</depth>
  </size>
  <segmented>0</segmented>
${objects}
</annotation>
`;
}

/** Minimal regex-based reader — matches the shape written by buildVocXml above. */
export function parseVocXml(xmlText) {
  const boxes = [];
  const objectRe = /<object>([\s\S]*?)<\/object>/g;
  let m;
  while ((m = objectRe.exec(xmlText))) {
    const chunk = m[1];
    const className = (chunk.match(/<name>([\s\S]*?)<\/name>/) || [])[1]?.trim() || 'unknown';
    const xmin = Number((chunk.match(/<xmin>([\s\S]*?)<\/xmin>/) || [])[1] || 0);
    const ymin = Number((chunk.match(/<ymin>([\s\S]*?)<\/ymin>/) || [])[1] || 0);
    const xmax = Number((chunk.match(/<xmax>([\s\S]*?)<\/xmax>/) || [])[1] || 0);
    const ymax = Number((chunk.match(/<ymax>([\s\S]*?)<\/ymax>/) || [])[1] || 0);
    boxes.push({ className, x: xmin, y: ymin, w: xmax - xmin, h: ymax - ymin });
  }
  return { boxes };
}
