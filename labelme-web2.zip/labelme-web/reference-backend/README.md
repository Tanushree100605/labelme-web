# Reference backend (optional — for testing the frontend only)

**This is not part of the frontend deliverable.** Your team's real backend
should be built separately by whoever owns that part of the project, against
[`../docs/API_CONTRACT.md`](../docs/API_CONTRACT.md).

This is a small, self-contained Node/Express implementation of that exact
contract, included so the frontend can be tested and demoed end-to-end
without waiting on the rest of the team. It's a genuine, working
implementation (it really reads/writes COCO JSON / Pascal VOC XML / YOLO TXT
files on disk) — feel free to also use it as a starting point or reference if
that helps whoever's building the real one, but treat it as scaffolding, not
your submission.

## Run it

```bash
cd reference-backend
npm install
npm start
```

Starts on `http://localhost:8000/api` by default (matches `js/config.js`).
Set `PORT=1234 npm start` to use a different port (and update
`API_BASE_URL` in `js/config.js` to match).

## What it does

- Scans a folder path you give it for images.
- Detects and parses existing `annotations.json` / `.xml` / `.txt` files that
  match the chosen format, so reopening a folder resumes prior work.
- Writes annotations back in the chosen format on every save.
- Keeps session state (which folder, which format, current classes) in an
  in-memory `Map` — no database, restarts clear it, exactly per spec.
