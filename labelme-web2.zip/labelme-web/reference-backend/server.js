import express from 'express';
import cors from 'cors';
import fs from 'fs/promises';
import path from 'path';
import sizeOf from 'image-size';
import * as coco from './formats/coco.js';
import * as voc from './formats/voc.js';
import * as yolo from './formats/yolo.js';

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8000;
const IMAGE_EXT = new Set(['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.gif']);
const MIME = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.bmp': 'image/bmp', '.webp': 'image/webp', '.gif': 'image/gif' };

// sessionId -> { dirPath, folderName, format, classes: [{id,name}], images: [{name,width,height}], annotations: {name: boxes[]} }
const sessions = new Map();

function baseName(name) { return name.slice(0, name.lastIndexOf('.')) === '' ? name : name.slice(0, name.lastIndexOf('.')); }

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.post('/api/folders/open', async (req, res) => {
  const { path: folderPath, format } = req.body || {};
  if (!folderPath || !['coco', 'voc', 'yolo'].includes(format)) {
    return res.status(400).json({ message: 'path and a valid format are required' });
  }

  const resolved = path.resolve(folderPath);
  let stat;
  try {
    stat = await fs.stat(resolved);
  } catch {
    return res.status(404).json({ message: `Folder not found: ${folderPath}` });
  }
  if (!stat.isDirectory()) {
    return res.status(404).json({ message: `Not a directory: ${folderPath}` });
  }

  const entries = await fs.readdir(resolved, { withFileTypes: true });
  const imageNames = entries
    .filter(e => e.isFile() && IMAGE_EXT.has(path.extname(e.name).toLowerCase()))
    .map(e => e.name)
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  const images = await Promise.all(imageNames.map(async name => {
    try {
      const buf = await fs.readFile(path.join(resolved, name));
      const dims = sizeOf(buf);
      return { name, width: dims.width || 0, height: dims.height || 0 };
    } catch {
      return { name, width: 0, height: 0 };
    }
  }));

  const sessionId = Buffer.from(resolved).toString('base64url');
  const session = {
    dirPath: resolved,
    folderName: path.basename(resolved),
    format,
    classes: [],
    images,
    annotations: {},
  };

  await loadExisting(session);
  sessions.set(sessionId, session);

  res.json({
    sessionId,
    folderName: session.folderName,
    format: session.format,
    images: session.images,
    classes: session.classes,
    annotations: session.annotations,
  });
});

app.get('/api/folders/:sessionId/images/:imageName/file', async (req, res) => {
  const session = sessions.get(req.params.sessionId);
  if (!session) return res.status(404).json({ message: 'Unknown session' });
  const imageName = decodeURIComponent(req.params.imageName);
  if (!session.images.some(i => i.name === imageName)) {
    return res.status(404).json({ message: `Image not found: ${imageName}` });
  }
  const filePath = path.join(session.dirPath, imageName);
  const ext = path.extname(imageName).toLowerCase();
  res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
  try {
    const buf = await fs.readFile(filePath);
    res.send(buf);
  } catch (err) {
    res.status(404).json({ message: `Could not read image: ${imageName}` });
  }
});

app.put('/api/folders/:sessionId/classes', async (req, res) => {
  const session = sessions.get(req.params.sessionId);
  if (!session) return res.status(404).json({ message: 'Unknown session' });
  const classes = req.body?.classes;
  if (!Array.isArray(classes)) return res.status(400).json({ message: 'classes must be an array' });

  session.classes = classes.map(c => ({ id: c.id, name: c.name }));

  if (session.format === 'yolo') {
    await fs.writeFile(path.join(session.dirPath, yolo.YOLO_CLASSES_FILENAME), yolo.buildClassesTxt(session.classes));
  }
  if (session.format === 'coco') {
    await writeCoco(session);
  }

  res.json({ ok: true });
});

app.put('/api/folders/:sessionId/annotations/:imageName', async (req, res) => {
  const session = sessions.get(req.params.sessionId);
  if (!session) return res.status(404).json({ message: 'Unknown session' });
  const imageName = decodeURIComponent(req.params.imageName);
  const img = session.images.find(i => i.name === imageName);
  if (!img) return res.status(404).json({ message: `Image not found: ${imageName}` });

  const boxes = req.body?.boxes;
  if (!Array.isArray(boxes)) return res.status(400).json({ message: 'boxes must be an array' });

  const validIds = new Set(session.classes.map(c => c.id));
  if (boxes.some(b => !validIds.has(b.classId))) {
    return res.status(422).json({ message: 'One or more boxes reference an unknown classId' });
  }

  session.annotations[imageName] = boxes.map(b => ({ id: b.id, classId: b.classId, x: b.x, y: b.y, w: b.w, h: b.h }));

  if (session.format === 'coco') {
    await writeCoco(session);
  } else if (session.format === 'yolo') {
    const classIds = session.classes.map(c => c.id);
    const txt = yolo.buildYoloTxt(session.annotations[imageName], img.width, img.height, id => classIds.indexOf(id));
    await fs.writeFile(path.join(session.dirPath, yolo.yoloFilenameFor(baseName(imageName))), txt);
  } else if (session.format === 'voc') {
    const xml = voc.buildVocXml({
      imageName, folderName: session.folderName, width: img.width, height: img.height,
      boxes: session.annotations[imageName],
      classNameOf: id => session.classes.find(c => c.id === id)?.name,
    });
    await fs.writeFile(path.join(session.dirPath, voc.vocFilenameFor(baseName(imageName))), xml);
  }

  res.json({ ok: true });
});

async function writeCoco(session) {
  const doc = coco.buildCoco(session);
  await fs.writeFile(path.join(session.dirPath, coco.COCO_FILENAME), JSON.stringify(doc, null, 2));
}

async function readIfExists(filePath) {
  try { return await fs.readFile(filePath, 'utf-8'); } catch { return null; }
}

let nextClassId = 1;
function ensureClassByName(session, name) {
  let existing = session.classes.find(c => c.name === name);
  if (existing) return existing.id;
  const id = nextClassId++;
  session.classes.push({ id, name });
  return id;
}

async function loadExisting(session) {
  if (session.format === 'coco') {
    const text = await readIfExists(path.join(session.dirPath, coco.COCO_FILENAME));
    if (!text) return;
    try {
      const { classes, annotationsByImage } = coco.parseCoco(JSON.parse(text));
      classes.forEach(c => { if (!session.classes.some(x => x.id === c.id)) session.classes.push(c); nextClassId = Math.max(nextClassId, c.id + 1); });
      session.annotations = annotationsByImage;
    } catch (err) { console.warn('Could not parse existing annotations.json', err); }
    return;
  }

  if (session.format === 'yolo') {
    const classesText = await readIfExists(path.join(session.dirPath, yolo.YOLO_CLASSES_FILENAME));
    const names = classesText ? yolo.parseClassesTxt(classesText) : [];
    const idForIndex = names.map(n => ensureClassByName(session, n));
    for (const img of session.images) {
      const text = await readIfExists(path.join(session.dirPath, yolo.yoloFilenameFor(baseName(img.name))));
      if (!text) continue;
      const boxes = yolo.parseYoloTxt(text, img.width, img.height);
      session.annotations[img.name] = boxes.map(b => ({
        classId: idForIndex[b.classIndex] ?? ensureClassByName(session, `class_${b.classIndex}`),
        x: b.x, y: b.y, w: b.w, h: b.h,
      }));
    }
    return;
  }

  if (session.format === 'voc') {
    for (const img of session.images) {
      const text = await readIfExists(path.join(session.dirPath, voc.vocFilenameFor(baseName(img.name))));
      if (!text) continue;
      const { boxes } = voc.parseVocXml(text);
      session.annotations[img.name] = boxes.map(b => ({
        classId: ensureClassByName(session, b.className),
        x: b.x, y: b.y, w: b.w, h: b.h,
      }));
    }
  }
}

app.listen(PORT, () => {
  console.log(`Reference backend listening on http://localhost:${PORT}/api`);
});
