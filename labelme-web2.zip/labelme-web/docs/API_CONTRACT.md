# API Contract — Frontend ⇄ Backend

This is the contract the frontend (`js/apiClient.js`) is built against. The
backend can be implemented in whatever language/framework your team prefers
(Node/Express, Python/FastAPI or Flask, etc.) as long as it exposes these
routes with these shapes. Base URL is configured in `js/config.js`
(`API_BASE_URL`, default `http://localhost:8000/api`).

Design principles, matching what was asked for:

- **No database.** The backend's job is filesystem access + format
  conversion. State that matters (images, annotations, classes) lives as
  files on disk, in the folder the user pointed at.
- **No auth.** Single user, local/dev use.
- **Format is fixed per folder.** Chosen once in `POST /folders/open`; the
  backend is responsible for detecting/parsing any pre-existing annotation
  files in that format so work can resume.
- **The frontend never encodes/decodes COCO/VOC/YOLO.** It only ever sends
  and receives a generic box shape: `{ id, classId, x, y, w, h }` in
  original-image pixel coordinates, top-left origin. All translation to/from
  COCO JSON / Pascal VOC XML / YOLO TXT happens server-side.

---

## `GET /api/health`

Liveness check, polled periodically by the frontend to show a connection
indicator.

**Response `200`**
```json
{ "status": "ok" }
```

---

## `POST /api/folders/open`

Opens a folder on the backend's filesystem for a new (or resumed) annotation
session, using the chosen format for the whole folder. Scans the folder for
supported images (`.jpg .jpeg .png .bmp .webp .gif`, non-recursive), and — if
annotation files matching the requested format already exist there — parses
them back so the user can resume prior work.

**Request**
```json
{
  "path": "/absolute/or/relative/path/to/folder",
  "format": "coco" | "voc" | "yolo"
}
```

**Response `200`**
```json
{
  "sessionId": "a1b2c3",
  "folderName": "cats",
  "format": "coco",
  "images": [
    { "name": "img001.jpg", "width": 1024, "height": 768 },
    { "name": "img002.jpg", "width": 1280, "height": 720 }
  ],
  "classes": [
    { "id": 1, "name": "cat" },
    { "id": 2, "name": "dog" }
  ],
  "annotations": {
    "img001.jpg": [
      { "id": 1, "classId": 1, "x": 120, "y": 45, "w": 200, "h": 150 }
    ],
    "img002.jpg": []
  }
}
```
`classes` and `annotations` are `[]` / `{}` for a brand-new folder with no
prior annotation files. `sessionId` is an opaque token the frontend passes on
every subsequent call for this folder (a good implementation: hash of the
resolved absolute path, or a short-lived in-memory session id — no DB
required, an in-process map is fine).

**Errors**
- `400` — missing/invalid `path` or `format`.
- `404` — path doesn't exist or isn't a directory.
  ```json
  { "message": "Folder not found: /some/path" }
  ```
- `403` — path exists but isn't readable/writable.

---

## `GET /api/folders/:sessionId/images/:imageName/file`

Returns the raw image bytes for one image in the session's folder, with the
correct `Content-Type` (`image/jpeg`, `image/png`, etc.). Used directly as an
`<img src>` / canvas draw source — no base64, no JSON wrapper.

**Response `200`** — binary image body.
**Errors** `404` if session or image name isn't found.

---

## `PUT /api/folders/:sessionId/classes`

Replaces the full class list for this session and persists it (e.g. for
YOLO, (re)writes the shared `classes.txt`; for COCO/VOC the class registry
can just be kept so future per-image saves know valid ids/names).

**Request**
```json
{ "classes": [ { "id": 1, "name": "cat" }, { "id": 2, "name": "dog" } ] }
```

**Response `200`**
```json
{ "ok": true }
```

---

## `PUT /api/folders/:sessionId/annotations/:imageName`

Replaces all boxes for one image and writes them to disk in the session's
format:
- **YOLO**: writes `<imageBaseName>.txt` (normalized boxes) using the class
  list's current order/ids for the class index.
- **VOC**: writes `<imageBaseName>.xml`.
- **COCO**: updates that image's entries inside the folder's shared
  `annotations.json` (rewrite the whole document server-side; the frontend
  calls this endpoint once per image, not once for the whole folder).

**Request**
```json
{
  "boxes": [
    { "id": 1, "classId": 1, "x": 120, "y": 45, "w": 200, "h": 150 }
  ]
}
```
Coordinates are in original image pixels, `x`/`y` = top-left corner. `id` is
frontend-generated and only used for the frontend's own list rendering — the
backend can ignore it or use it as a stable annotation id if convenient.

**Response `200`**
```json
{ "ok": true }
```

**Errors** `404` if session or image isn't found; `422` if a `classId` isn't
in the current class list.

---

## Error shape (all endpoints)

Any non-2xx response should return JSON with a human-readable `message` so
the frontend can surface it in a toast:
```json
{ "message": "Folder not found: /some/path" }
```

## CORS

Since the frontend and backend are served from different origins/ports
during development, the backend needs permissive CORS (at least
`Access-Control-Allow-Origin: *` or the frontend's dev origin) on all of the
above routes.
