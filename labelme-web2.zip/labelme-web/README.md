# Annotator — Frontend (Browser-based Image Labeling, LabelMe-style)

This is the **frontend** of a client-server image annotation tool. It talks
to a separate backend API (built by the rest of the team — see
[`docs/API_CONTRACT.md`](docs/API_CONTRACT.md)) which handles all filesystem
access: reading a folder of images and writing annotation files back into it.
The frontend owns everything the user sees and interacts with: the image
list, class management, and the box-drawing canvas.

- No database, no login, no user roles — a single-user, local tool.
- No format-specific code in the frontend at all. It only ever sends/receives
  a generic box shape (`{ id, classId, x, y, w, h }` in pixel coordinates);
  the backend is responsible for reading/writing COCO JSON, Pascal VOC XML,
  or YOLO TXT on disk.

## Features

- **Open a folder** by path (resolved by the backend) and pick one
  annotation format for that folder: **COCO JSON**, **Pascal VOC XML**, or
  **YOLO TXT**.
- **Bounding box annotation**: draw, move, and resize boxes on a canvas
  overlay.
- **Class management**: create classes on the fly (each gets its own color),
  pick the active class before drawing, delete classes (with confirmation if
  they're in use).
- **Image list** sidebar to browse/jump between every image in the folder; a
  dot marks images that already have annotations.
- **Autosave**: annotations save to the backend a moment after you stop
  editing, plus on demand via the Save button or `Ctrl+S`.
- **Resumes existing work**: if the backend reports existing annotations/
  classes for the folder+format, they're loaded back in on open.
- A live **backend connection indicator** in the top bar.

## Requirements

A backend implementing [`docs/API_CONTRACT.md`](docs/API_CONTRACT.md),
reachable at the URL configured in `js/config.js` (`API_BASE_URL`, default
`http://localhost:8000/api`). Update that one constant if your teammate's
backend runs elsewhere.

No browser-specific APIs are required beyond a normal modern browser (Chrome,
Edge, Firefox, Safari all fine) — the earlier File System Access API
dependency is gone now that the backend owns filesystem access.

## Running it

Static site, no build step, no dependencies:

```bash
npx serve .
# or: python3 -m http.server 8000
```

Then open the printed URL in your browser. Make sure the backend is running
first (or start it in parallel) — the top bar shows a "backend connected /
unreachable" indicator.

## Using it

1. Click **Open folder**, type in a path to a folder of images **on the
   machine running the backend**, and pick a format. This choice applies to
   every image in that folder.
2. Add one or more classes in the right-hand panel (saved to the backend
   immediately).
3. Select a class, then click-and-drag on the image to draw a box. Click an
   existing box to select it — drag its corner handles to resize, drag its
   body to move it, or delete it with the ✕ button, `Delete`/`Backspace`, or
   from the annotation list.
4. Use the image list on the left (or `←`/`→`) to move between images.
   Annotations autosave to the backend; the status indicator shows
   Saving… / Saved.

## Project structure

```
index.html                 App shell / layout
css/styles.css              Styling (dark, tool-focused UI)
js/config.js                 API_BASE_URL — point this at your backend
js/apiClient.js              All fetch() calls to the backend live here
js/state.js                  Central app state + tiny pub/sub
js/persistence.js            Bridges app state <-> apiClient (open/save)
js/classManager.js           Class list UI (right panel, top)
js/imageList.js               Image list UI (left panel)
js/annotationList.js          Per-image annotation list UI (right panel, bottom)
js/canvasEditor.js            Canvas rendering + draw/move/resize interactions
js/main.js                    Wires it all together: open-folder flow,
                               navigation, autosave, keyboard shortcuts
docs/API_CONTRACT.md          The request/response spec the backend implements
```

## Known limitations (by design, per current scope)

- Bounding boxes only (no polygons/polylines/points) — keeps a single
  annotation model consistent across all three export formats.
- No undo/redo history.
- No recursive folder scanning (backend lists images directly inside the
  requested folder only, per the contract).
- No authentication, accounts, or multi-user sync.

## License

MIT — see `LICENSE`.
